A Pen created at CodePen.io. You can find this one at http://codepen.io/ArchivalBoat50/pen/gmQyZQ.

 A little animation of a spaceship landing on what may not have been an uninhabited planet.